---
name: HARE Air Studio
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#4b626d'
  on-secondary: '#ffffff'
  secondary-container: '#cbe3f0'
  on-secondary-container: '#4f6671'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1a1c1c'
  on-tertiary-container: '#838484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#cee6f3'
  secondary-fixed-dim: '#b2cad7'
  on-secondary-fixed: '#051e28'
  on-secondary-fixed-variant: '#334a54'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-xl:
    fontFamily: Bodoni Moda
    fontSize: 72px
    fontWeight: '600'
    lineHeight: 80px
    letterSpacing: -0.02em
  display-xl-mobile:
    fontFamily: Bodoni Moda
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 40px
    fontWeight: '500'
    lineHeight: 48px
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  nav-link:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
spacing:
  unit: 8px
  container-max-width: 1440px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 128px
---

## Brand & Style

This design system embodies the intersection of avant-garde Japanese fashion and precision logistics. The brand personality is architectural, sophisticated, and decisively modern. It balances the "HARE" (high-concept design) with the "Air" (efficiency and movement) and the "Studio" (educational curation).

The design style is a hybrid of **Minimalism** and **High-Contrast Editorial**. It utilizes heavy whitespace to allow product photography to breathe, punctuated by sharp, aggressive typography that signals a premium, professional edge. The interface should feel like a digital luxury lookbook—structured, rhythmic, and uncompromisingly clean.

**Emotional Response:**
- **Authority:** Trust in the "Studio" styling expertise.
- **Exclusivity:** The "HARE" designer aesthetic.
- **Precision:** The "Air" logistical speed.

## Colors

The palette is rooted in a **Monochrome Foundation** to maintain a high-fashion aesthetic. 

- **Primary (#0F0F0F):** An "Obsidian Black" used for high-contrast typography, borders, and structural elements. It provides the "heavy" weight associated with premium suit trousers.
- **Secondary (#8FA7B3):** "Air Blue." A muted, desaturated sky tone that represents the logistical speed and clarity of the brand. It is used sparingly for call-to-actions and status indicators.
- **Neutral (#F9F9F9 & #E5E5E5):** "Studio Greys." These provide the canvas. The light grey backgrounds prevent the harshness of pure white while maintaining a crisp, laboratory-like styling environment.

The system uses a "High-Contrast" logic: light backgrounds with deep black elements create a rhythmic, barcode-like visual interest across the layout.

## Typography

The typography strategy is a dialogue between tradition and the future.

- **The Serif (Bodoni Moda):** Used for headlines and display text. Its high-contrast strokes evoke the elegance of luxury fashion editorials and Japanese craftsmanship. 
- **The Sans-Serif (Hanken Grotesk):** Used for body copy, navigation, and functional labels. It is sharp, contemporary, and highly legible, representing the "Air" and "Studio" components of the brand.

**Hierarchy Rules:**
- Large display text should use tight letter-spacing for a modern, "compact" feel.
- Functional labels (e.g., SKU numbers, sizes, delivery status) should always be in **uppercase** with increased letter-spacing to mimic industrial shipping manifests.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy on desktop to ensure precise architectural alignment. 

- **Grid System:** A 12-column grid with 24px gutters. Content is often intentionally offset or spans unusual column counts (e.g., 5 columns) to mirror the "unique cuts" of the clothing.
- **Whitespace:** High-end appeal is achieved through "Section Gaps" of 128px. This creates a rhythmic pause between different styling stories or product categories.
- **Mobile Adaptivity:** On mobile, the margins tighten to 20px, and the grid collapses to a single-column flow, emphasizing verticality and high-quality photography.

Margins are generous to ensure the UI never feels crowded, maintaining the "Air" aspect of the brand identity.

## Elevation & Depth

This design system rejects heavy shadows in favor of **Tonal Layers** and **Bold Outlines**.

- **Flat Depth:** Hierarchy is established through color blocking rather than shadows. Elements that need to "pop" are placed on a Primary Black background with White text.
- **Low-Contrast Outlines:** Containers (like product cards or input fields) use 1px solid borders in `#E5E5E5` (Studio Grey). This creates a structured, blueprint-like feel without adding visual weight.
- **Zero Shadow Policy:** Avoid ambient shadows. If depth is required for a floating element (like a modal), use a sharp, 100% opacity "hard shadow" offset by 4px in Primary Black to maintain the avant-garde aesthetic.

## Shapes

The shape language is **Architectural and Sharp**.

All UI elements—buttons, cards, input fields, and images—must have **0px corner radius**. The sharp corners reflect the precision of heavy-weight suit trousers and the "cut" of the designer aesthetic. This lack of rounding creates a more aggressive, professional, and high-fashion silhouette that differentiates the product from softer, mass-market e-commerce platforms.

## Components

### Buttons
- **Primary:** Solid Black background, White text, 0px radius. Hover state transitions to Air Blue.
- **Secondary:** Transparent background, 1px Black border, Black text.
- **Text:** Uppercase with 0.1em letter-spacing and a simple underline.

### Cards (Product/Studio)
- Product cards are borderless with the image taking up 100% width. 
- Information (Price/Name) is placed below in a structured, left-aligned layout using Hanken Grotesk.

### Input Fields
- Underline-only style or a full 1px grey border. 
- Placeholder text in a light grey, transitioning to black on focus. No rounded corners.

### Chips & Tags
- Rectangular boxes with 1px borders. 
- Used for "Fast Delivery" or "Studio Pick" labels. 

### Navigation
- Top-tier navigation uses the `nav-link` style. 
- Simple, thin horizontal lines separate the header from the content, reinforcing the grid-based layout.

### Unique Component: "The Blueprint Slider"
A custom image slider for the "Studio" section that shows the "construction" of a garment (technical drawing) overlaid on the final photography using a simple toggle.